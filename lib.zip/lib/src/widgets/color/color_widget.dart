import 'package:flutter/material.dart';

class AppColor{
  static Color white = Colors.white;
  static Color black = Colors.black;
  static Color grey = Color(0xFF363636);
  static Color normalgrey = Color(0xFF979797);
  static Color ButtonColor = Color(0xFF8687E7);
  static Color Bacground = Color(0xFF121212);
  static Color Black27 = Color(0xFF272727);
  static Color red = Colors.red;
  static Color green = Colors.green;
  static Color blue = Color(0xFF809CFF);
  static Color reda = Color(0xFFFF8080);
  static Color orange = Color(0xFFFFCC80);
  static Color greenb = Color(0xFF80FFD1);
  static Color pink = Color(0xFFFC80FF);
  static Color blue2 = Color(0xFF80FFFF);
  static Color gren2 = Color(0xFFCCFF80);
  static Color gren3 = Color(0xFF80FFA3  );
  static Color blue3 = Color(0xFF80D1FF);
}